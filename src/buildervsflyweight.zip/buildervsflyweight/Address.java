package buildervsflyweight;

public class Address {

}
