package buildervsflyweight;

public class HealthProfile {

}
