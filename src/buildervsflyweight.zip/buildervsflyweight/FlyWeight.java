package buildervsflyweight;

public interface FlyWeight {

	public int countAttendants( Customer customer);
}
