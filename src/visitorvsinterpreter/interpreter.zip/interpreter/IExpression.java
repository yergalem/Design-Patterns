package visitorvsinterpreter.interpreter;

public interface IExpression {
	public int interpret();
}
